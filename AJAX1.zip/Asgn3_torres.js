 /*****************************************
File: Asgn3_torres.js
Author: Samuel Torres
Assignment: 3
Create Date: 02/11/2018
Last Modified: 03/09/2018
Class: CSWB 135 ADV JavaScript
****************************************/
$(document).ready(function() {
	
	$("#btnSend").click(function(event){
		
		 event.preventDefault();

	 var myData = $('#frmContact').serialize();
	 
	 $.ajax({
                    url: 'Asgn3_torres.php',  // the script to process the form
                    data: myData,    // the data we want to send
                        
                    success: function (result) {
                        $('#result').html(result);
                       
                        
                        if(result != "Something went wrong. Please fill in all information and try again!"){
                           
                            $('#frmContact, p:first-of-type, h1, h2').hide();
                        }

                    },
                    error: function (xhr, status, error) {
                        $('#result').html("Error: " + xhr.status + " " + xhr.statusText);
                    }

                }); // end $.ajax


       


	
	/*////SAMS CODE $.ajax({
                    type: 'GET',
					url: 'Asgn3_torres.php',  // the script to process the form
                    data: myData,    // the data we want to send

					success: function (result) {
						
							
						$('#result').html(result);
						
					},
                     
					
					error: function (xhr, status, error) {
						
						
						$('#result').html("Error: " + xhr.status + " " + xhr.statusText);
					
					
						
					}//end error function
					
					
					
                }); // end $.ajax function*////SAMS CODE
			 
		
	
	
	}); // End of Click function
	
});// End of doc.Ready Function