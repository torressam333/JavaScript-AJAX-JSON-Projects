 /*****************************************
File: Asgn1_torres.js
Author: Samuel Torres
Assignment: 1
Create Date: 02/11/2018
Last Modified: 02/15/2018
Class: CSWB 135 ADV JavaScript
****************************************/

 window.onload = function() {
        
     // reference the button to be clicked   
     var btnCalculate = document.getElementById("calculate");
     
     // calls the function when the button is clicked
       btnCalculate.onclick =calculateResult; 
    
    }

     // code to be called when button is clicked goes here
    function calculateResult() {
        
       // set test variable to determine when to compute and display results
       var isValid = true;
        
       // variable to hold the BMI value
       var theBMI = 0; 
        
       // variable to hold the descriptive category
       var theCategory = "";          
            
       // retrieve the value for weight 
       var theWeight = document.getElementById('weight').value;  
        
       // retrieve the value for height    
       var theHeight = document.getElementById('height').value;  
	   
       // check the value for the weight
       if (isNaN(theWeight) || theWeight <=0) {
		   
		for(var i = 0; i< document.getElementsByClassName('error').length; i++){
		   document.getElementsByClassName('error')[0].firstChild.nodeValue = "Enter a valid weight";
	   }
           isValid = false;
       }  
        
       // check the value for the height
       if (isNaN(theHeight)|| theHeight <=0) {
		   
          for(var i = 0; i< document.getElementsByClassName('error').length; i++){
		   document.getElementsByClassName('error')[1].firstChild.nodeValue = "Enter a valid height";
	   }
           isValid = false;
	   }
	   
	   if(theWeight){
	   for(var i = 0; i< document.getElementsByClassName('error').length; i++){
		   document.getElementsByClassName('error')[0].firstChild.nodeValue = "";
		   
	   }
	   isValid = false;
	   }
	   
	   if(theHeight && theWeight){
	   for(var i = 0; i< document.getElementsByClassName('error').length; i++){
		   document.getElementsByClassName('error')[1].firstChild.nodeValue = "";
		   
	   }
	   isValid = true;
	   }
	   
       if (isValid) {    
       // formula to calcluate BMI 
       theBMI = ((theWeight / Math.pow(theHeight,2)) * 703).toFixed(2); 
   
        //nested if to determine the category
        if (theBMI >= 30){
          theCategory = "Obese";
        }
        else if (theBMI >= 25 && theBMI < 30){
          theCategory = "Overweight";
        }
        else if (theBMI >= 18 && theBMI < 25){
          theCategory = "Normal";
        }
         else if (theBMI < 18){
          theCategory = "Underweight";
        }
        else {
            alert("There is a problem")
        }     
         
	//Samuel's Code for changing the text output to the browser

		var elem =  document.createElement("h2");
		
		var myText = document.createTextNode("Your BMI is " + theBMI +  " which means you are " + theCategory);
		
		elem.appendChild(myText);
		
		 var theParent =  document.getElementById("results");
		 
		theParent.appendChild(elem);
		
		var attr = document.createAttribute("class");
		
		elem.setAttribute("class", "blue");
		
		
	//removing child node 
	if(theParent.childNodes.length > 1){
		theParent.removeChild(theParent.childNodes[1]);
	}
	
	/*****ensuring that only one line of text is displayed on the page per click
	the results change occurring only on one line*****/
	
	if(theParent.childNodes.length == 1){
		theParent.removeChild(theParent.childNodes[0]);
		theParent.appendChild(elem);
	}
		 
   } // end if isValid
        
 } // end calculateResult function
        