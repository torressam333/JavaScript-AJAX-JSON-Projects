var $ = function (id) {
		return document.getElementById(id);
	}
	
    var processInfo = function()
{
	var myFirstName = $("firstname").value;
	var myLastName = $("lastname").value;
	var myNumPets = $("numpets").value;
	var myMsg = "";
	var Pet1 = $("pet1").value;
	var Pet2 = $("pet2").value;
	var Pet3 = $("pet3").value;
	var mySpan = "";
		 
	document.getElementById("firstname_error").innerHTML = mySpan;
	document.getElementById("lastname_error").innerHTML = mySpan;
	document.getElementById("numpets_error").innerHTML = mySpan;
	
	if(!myFirstName) 
	{
	    document.getElementById("firstname_error").innerHTML = " Please enter your first name "
		
	}
	
	if(!myLastName) 
	{
		document.getElementById("lastname_error").innerHTML =  " Please enter your last name "
	}
	
	if(!myNumPets) 
	{
		document.getElementById("numpets_error").innerHTML = " Please enter the number of pets you have  "
	}	
	
	var Pets = "";
	
	for(cntr = 1; cntr <= 3; cntr++) 
		
		var myPetId = "pet" + cntr;
			
		var myPetName = $(myPetId).value;
	 
	    Pets += myPetName;
	
	var today = new Date();  
	
	var todaytext = today.toDateString();

	var todaymm  = today.getMonth() + 1;
	var todaydd  = today.getDate();
	var todayyyy = today.getFullYear();
	var todayformatted = todaymm  + '-'  + todaydd + '-' + todayyyy;


	if(myLastName && myFirstName && todayformatted && myNumPets)
	{
		myMsg += " Your name is listed as " + myLastName + ", "
		+ myFirstName + " and today's date is " + todayformatted + ". "; 
	}
	
	if(myNumPets == 1)
	{
		myMsg += " Your pet #1 is named " + Pet1 + ".";
	}
	
	if(myNumPets == 2)
	{
		myMsg += " Your pet #1 is named " + Pet1 + "." + " Your pet #2 is named " + Pet2 + ".";
	}
	
	if(myNumPets == 3)
	{
		myMsg += " Your pet #1 is named " + Pet1 + "." 
		+ " Your pet #2 is named " + Pet2 + "." 
		+ " Your pet #3 is named " + Pet3 + ".";
	}
			$("message").innerHTML = myMsg;	
	
}

window.onload = function () 
{
    $("mybutton").onclick = processInfo;
}
