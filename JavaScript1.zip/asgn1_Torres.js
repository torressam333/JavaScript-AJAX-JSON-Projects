var $ = function (id) {
			return document.getElementById(id);
}

var calculateSleep = function ()
{
	var myFirstName = $("firstname").value;
	var myAge = $("age").value;
	var myHoursSleeping = $("hours").value;
	
	var myAgeInt = parseInt(myAge);
	var myHoursSleepingInt = parseInt(myHoursSleeping);	
	
	var mySleep = myAgeInt * myHoursSleepingInt / 24;
			
	if(!myFirstName || !myAgeInt || !myHoursSleepingInt){
		$("firstnameerror").innerHTML = "Enter Your First Name";
		$("ageerror").innerHTML = "Enter Your age";
		$("hourserror").innerHTML = "Enter The Number of Hours you Sleep Per Night";
	}
	else{
	
	var myText = "Hi there, " + myFirstName + " You have slept " + Math.round(mySleep) + " years of your life away. "; 	   
	$("mymsg").innerHTML = myText;}
	
	if(myFirstName){
		$("firstnameerror").innerHTML = "";
	}
		
	if(myAgeInt){
		$("ageerror").innerHTML = "";
	}
	
	if(myHoursSleepingInt){
		$("hourserror").innerHTML = "";
	}
	
}

window.onload = function ()
{
	$("mybutton").onclick = calculateSleep;  
}
