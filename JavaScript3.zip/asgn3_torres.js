var $ = function (id) {
    return document.getElementById(id);
}


function validateItems()

{

	var myFirstName = $('firstname').value;
	var myLastName = $('lastname').value;
    var myEmail = $('email').value;
	var myCity = $('city').value;
    var myEndMessageError = $('endmessage').value;
	
	var myDonation = $('donation').value;
	
	var myMessage = $('endmessage');

	var myErrorFlag = "N";

	var myFirstNameError = $('firstnameerror');
	var myLastNameError = $('lastnameerror');
	var myEmailError   = $('emailerror');
    var myTrueCityError = $('cityerror');
	var myDonationError = $('donationerror');
	var myEndMessageError = $('endmessage');
	
	myFirstNameError.innerHTML = "";
	myLastNameError.innerHTML = "";
	myEmailError.innerHTML = "";
	myTrueCityError.innerHTML = "";
	myDonationError.innerHTML = "";
	myEndMessageError.innerHTML = "";
	
	
	$('firstname').focus();
	
	if (myFirstName == '')
	{
		myFirstNameError.innerHTML = "Enter first name";
		myErrorFlag = "Y";
		 
	}
	

    if (myLastName == '')
		{
			myLastNameError.innerHTML  = "Enter last name";
			myErrorFlag = "Y";
	}
    
	
	if (myEmail == '')
	
	{
			myEmailError.innerHTML  = "Enter Email";
			myErrorFlag = "Y";
	}

    if (myCity == "-")
	
	{
			myTrueCityError.innerHTML  = "Select a city from the list";
			myErrorFlag = "Y";
	}
	
    
	if (myDonation == '')
	{
		myDonationError.innerHTML = "Enter donation amount";
		myErrorFlag = "Y";
	}
	
	if (isNaN(myDonation))
	{
			myDonationError.innerHTML  = "Amount must be numeric";
			myErrorFlag = "Y";
	} 
		 
	if (myErrorFlag == "Y")
		
	{
		myEndMessageError.innerHTML = "Patron not added!";
		myErrorFlag = "Y";
	}
    
	else 
	
	{
		$("myform").submit();
	}
	   
	 
	 return;
}
	
function addPatrons(myFirstName, myLastName, myEmail, myCity, myDonation, myErrorFlag, myEndMessageError) 
{

 
    var isValid = validateItems(myFirstName, myLastName, myEmail, myCity, myDonation, myErrorFlag, myEndMessageError);
	
	var myForm = $('myform');
	
	myForm.innerHTML = isValid;
 
	
	
}	

function clearFields()
{
 
    var myFirstName = $('firstname').value = "";
	var myLastName = $('lastname').value = "";
	var myEmail = $('email').value = "";
	var myCity = $('city').value = "-";
	var myDonation = $('donation').value = "";
	
	$('firstname').focus();

}
		 


window.onload = function ()
{
	$("addpatron").onclick = validateItems;
	$("clearfields").onclick = clearFields;
	
	

}