var BeatlesArray;

var $ = function (id) {
	return document.getElementById(id);
}

var processNames = function() 
{ 
	var myBeatlesStr = "";
	var myBeatles = "";
	
	for(i=0; i<BeatlesArray.length; i++) 
		{
			myBeatlesStr += i+1 + ". " + BeatlesArray[i]; 
			if(i<BeatlesArray.length - 1)
			{
			myBeatlesStr +=  ", "; 
			}

		} 

		$("list").innerHTML = myBeatlesStr; 
		
	}

	function Lennon()
	{
		$("john").border = "0px";
		$("paul").border = "0px";
		$("george").border = "0px";
		$("ringo").border = "0px";
		this.border = '4px';
		this.style.color = 'yellow';
		
		BeatlesArray.push("John");
	
	}
	
		function McCartney()
	{
		$("john").border = "0px";
		$("paul").border = "0px";
		$("george").border = "0px";
		$("ringo").border = "0px";
		this.border = '4px';
		this.style.color = 'yellow';
		
		BeatlesArray.push("Paul");
	
	}
	
		function Harrison()
	{
		$("john").border = "0px";
		$("paul").border = "0px";
		$("george").border = "0px";
		$("ringo").border = "0px";
		this.border = '4px';
		this.style.color = 'yellow';
		
		BeatlesArray.push("George");
	
	}
	
		function Starr()
	{
		$("john").border = "0px";
		$("paul").border = "0px";
		$("george").border = "0px";
		$("ringo").border = "0px";
		this.border = '4px';
		this.style.color = 'yellow';
		
		BeatlesArray.push("Ringo");
	
	}
	
	window.onload = function () {
		$("showlist").onclick = processNames;
		$("john").onclick = Lennon;
		$("paul").onclick = McCartney;
		$("george").onclick = Harrison;
		$("ringo").onclick = Starr;

	BeatlesArray = new Array(); 
	}