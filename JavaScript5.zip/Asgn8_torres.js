/*****************************************
File: Asgn8.js
Author: Samuel Torres
Assignment: 8
Create Date: 11/17/2017
Last Modified: 11/27/2017
****************************************/
var $ = function (id) {
	return document.getElementById(id)
	}

window.addEventListener("load",function(){ //function 1

	var today = new Date ();
	
	
	var todaytext = today.toDateString();

	var todaymm  = today.getMonth() + 1;
	var todaydd  = today.getDate();
	var todayyyy = today.getFullYear();
	var todayformatted = todaymm  + '/'  + todaydd + '/' + todayyyy;
	
	$("today").innerHTML = (todayformatted);
});

var adding = function () //function 2
{

	var newInput = document.createElement("input");
	var newBreak = document.createElement("br");
	var myparent = $("todolist");
	
	newInput.setAttribute("title", "text");
	newInput.setAttribute("class", "listitem");
	newInput.setAttribute("type", "text");
	myparent.appendChild(newInput);	
	myparent.appendChild(newBreak);
};

var sorting = function() { //function 3
  
  var listItemValues = new Array();
  
      nodeList = document.querySelectorAll("input[type=text]"); 
	 
 
  for (i = 0; i < nodeList.length; i++) {
	 
     node = nodeList[i];
     listItemValues.push(node.value); // Stores values.
  }
     $("displayitems").innerHTML = printSortedValues(listItemValues);
};

var printSortedValues = function(listItemValues) { //function 4
	
  listItemValues.sort(); // Sorting the values.

  var display = "";
  
  for (i = 0; i < listItemValues.length; i++) 
  
  {
      display += listItemValues[i] += "<br>" + "</span>";;
  }
    return display; // Return content with the sorted values.
};


window.onload = function () //function 5
{
	$("additem").onclick = adding;  
	$("sortitems").onclick = sorting;
}